import { legacy_createStore as createStore, combineReducers } from 'redux'
import { CollApsedReducer } from './reducers/CollapsedReducer.js'
import { LoadingReducer } from './reducers/Loading.js';
import { persistStore, persistReducer } from 'redux-persist'
import storage from 'redux-persist/lib/storage' // 注意导入方式


const persistConfig = {
    key: 'root',
    storage, // 使用新的导入项名称
    whitelist: ['需要持久化的组件名']
}

const reducer = combineReducers({
    CollApsedReducer,
    LoadingReducer
})

const persistedReducer = persistReducer(persistConfig, reducer);

let store = createStore(persistedReducer)
let persistor = persistStore(store)
export { store, persistor }
