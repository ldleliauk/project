import React, { forwardRef, useEffect, useState } from 'react'
import { Form, Input, Select } from 'antd'
const { Option } = Select;
const UseForm = forwardRef((props, ref) => {

    const [isDisabled, setisDisabled] = useState(false)
    const [form] = Form.useForm();
    const { roleId,region } = JSON.parse(localStorage.getItem('token'));
    const roleObj = {
        "1": "superadmin",
        "2": "admin",
        "3": "editor"
    }
    const checkRegionDisabled = (item) => {
        if (props.isupdate) {
            if (roleObj[roleId] === "superadmin") {
                return false
            } else {
                return true
            }
        } else {
            if (roleObj[roleId] === "superadmin") {
                return false
            } else {
                return item.value!==region
            }
        }
    }

    const checkRoleDisabled=(item)=>{
        if (props.isupdate) {
            if (roleObj[roleId] === "superadmin") {
                return false
            } else {
                return true
            }
        } else {
            if (roleObj[roleId] === "superadmin") {
                return false
            } else {
                return roleObj[item.id]!=="editor"
            }
        }
    }
    useEffect(() => {
        setisDisabled(props.isjy)
    }, [props.isjy])
    return (
        <div>
            <Form
                ref={ref}
                form={form}
                layout="vertical"
                name="form_in_modal"
                initialValues={{
                    modifier: 'public',
                }}
            >
                <Form.Item
                    name="username"
                    label="用户名"
                    rules={[
                        {
                            required: true,
                            message: '用户名不得为空',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item name="password" label="密码" rules={[
                    {
                        required: true,
                        message: '密码不得为空',
                    },
                ]}>
                    <Input />
                </Form.Item>
                <Form.Item name="region" label="区域" rules={

                    isDisabled ? [] : [{
                        required: true,
                        message: '区域不得为空'
                    }]

                }>
                    <Select disabled={isDisabled}>
                        {
                            props.regionList?.map(item => {
                                return <Option disabled={checkRegionDisabled(item)} value={item.value} key={item.id}>{item.title}</Option>
                            })
                        }
                    </Select>
                </Form.Item>
                <Form.Item name="roleId" label="角色" rules={[
                    {
                        required: true,
                        message: '角色不得为空',
                    },
                ]}>
                    <Select onChange={(value) => {
                        if (value === 1) {
                            setisDisabled(true);
                            ref.current.setFieldsValue({
                                region: ''
                            })
                        } else {
                            setisDisabled(false)
                        }
                    }}>
                        {
                            props.roleList?.map(item => {
                                return <Option disabled={checkRoleDisabled(item)} value={item.id} key={item.id}>{item.roleName}</Option>
                            })
                        }
                    </Select>
                </Form.Item>
            </Form>
        </div>
    )
})
export default UseForm