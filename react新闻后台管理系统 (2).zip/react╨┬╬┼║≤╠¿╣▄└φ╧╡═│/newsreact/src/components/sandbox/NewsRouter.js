import React, { useEffect, useState } from 'react'
import { Route, Switch, Redirect } from 'react-router-dom/cjs/react-router-dom.min'
import Home from '../../views/newssandbox/home/Home'
import Userlist from '../../views/newssandbox/userlist/Userlist'
import Rolelist from '../../views/newssandbox/rolelist/Rolelist'
import Rightlist from '../../views/newssandbox/rightlist/Rightlist'
import NotFound from '../../views/newssandbox/notfound/NotFound'
import Newsadd from '../../views/newssandbox/news-manage/Newsadd'
import NewsDraft from '../../views/newssandbox/news-manage/NewsDraft'
import NewsCategory from '../../views/newssandbox/news-manage/NewsCategory'
import Audit from '../../views/newssandbox/audit-manage/Audit'
import AuditList from '../../views/newssandbox/audit-manage/AuditList'
import Unpublished from '../../views/newssandbox/publish-manage/Unpublished'
import Published from '../../views/newssandbox/publish-manage/Published'
import Sunset from '../../views/newssandbox/publish-manage/Sunset'
import NewsPreview from '../../views/newssandbox/news-manage/NewsPreview'
import axios from 'axios'
import NewsUpdate from '../../views/newssandbox/news-manage/NewsUpdate'
import {Spin } from 'antd';
import {connect} from 'react-redux'
const localRouterMap = {
    "/home": Home,
    "/user-manage/list": Userlist,
    "/right-manage/role/list": Rolelist,
    "/right-manage/right/list": Rightlist,
    "/news-manage/add": Newsadd,
    "/news-manage/draft": NewsDraft,
    "/news-manage/category": NewsCategory,
    "/audit-manage/audit": Audit,
    "/audit-manage/list": AuditList,
    "/publish-manage/unpublished": Unpublished,
    "/publish-manage/published": Published,
    "/publish-manage/sunset": Sunset,
    "/news-manage/preview/:id":NewsPreview,
    "/news-manage/update/:id":NewsUpdate
}

function NewsRouter(props) {
    const [backRouteList, setbackRouteList] = useState([])
    useEffect(() => {
        Promise.all([
            axios.get('http://localhost:8000/rights'),
            axios.get('http://localhost:8000/children')
        ]).then(res => {
            setbackRouteList([...res[0].data, ...res[1].data]);

        })

    }, [])

    const { role: { rights } } = JSON.parse(localStorage.getItem('token'));

    const newrights=[...rights,'/home'];
    const checkRoute = (item) => {
        return localRouterMap[item.key] && (item.pagepermisson || item.routepermisson)
    }

    const chekUserPermission = (item) => {
       
        return newrights.includes(item.key)
    }

    return (
        <Spin size="large" spinning={props.isLoading}>
        <Switch>
            {
                backRouteList.map(item => {

                    if (checkRoute(item) && chekUserPermission(item)) {
                        return <Route path={item.key} key={item.key} component={localRouterMap[item.key]} exact></Route>
                    }
                    return null
                }

                )
            }
            <Redirect from='/' to='/home' exact />
            {
                backRouteList.length > 0 && <Route component={NotFound}></Route>
            }

        </Switch>
        </Spin>
    )
}

const mapStateToProps=({LoadingReducer:{isLoading}})=>{//props里面就会有属性
    return {
        isLoading
    }
  }


export default   connect(mapStateToProps)(NewsRouter);
