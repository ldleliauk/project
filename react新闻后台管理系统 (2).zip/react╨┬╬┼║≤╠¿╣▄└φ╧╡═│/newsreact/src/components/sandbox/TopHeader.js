import React, { useState } from 'react'
import { UserOutlined } from '@ant-design/icons';
import { Dropdown, Space, Avatar } from 'antd';
import { Layout } from 'antd';
import { Icon } from '@ant-design/compatible';
import { withRouter } from 'react-router-dom';
import {connect} from 'react-redux'
const { Header } = Layout;




const TopHeader = (props) => {
  const {username,role:{roleName}}=JSON.parse(localStorage.getItem('token'));

  const [collapsed, toggle] = useState(false)
  const items = [
    {
      key: '1',
      label: (
        <a>
         {roleName}
        </a>
      ),
    },
    {
      key: '2',
      label: (
        <a onClick={() => {
          localStorage.removeItem('token');
          props.history.replace('./login');
        }}>
          退出
        </a>
      ),
    }
  ];
  return (
    <Header style={{ background: '#fff', padding: '0,10px' }}>
      <Icon
        className="trigger"
        type={props.isCollapsed ? 'menu-unfold' : 'menu-fold'}
        onClick={() => {
          toggle(props.isCollapsed)
          props.changeCollapsed()
        }}
      />
      <div style={{ float: 'right' }}>
        <span>欢迎<span style={{fontSize:'18px',color:'#1E90FF',fontWeight:'bold',padding:'5px'}}>{username}</span>回来</span>
        <Dropdown
          menu={{
            items,
          }}
        >
          <a onClick={(e) => e.preventDefault()}>
            <Space>
              <Avatar size="large" icon={<UserOutlined />} />
            </Space>
          </a>
        </Dropdown>
      </div>
    </Header>
  )
}
const mapStateToProps=({CollApsedReducer:{isCollapsed}})=>{//props里面就会有属性
  return {
    isCollapsed
  }
}
const mapDispatchToProps={
  changeCollapsed(){
    return{
      type:'change_collapsed'
    }
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(withRouter(TopHeader));