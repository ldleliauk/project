import React, { useEffect, useState } from 'react'
import { Layout, Menu } from 'antd';
import { Icon } from '@ant-design/compatible';
import './index.css'
import SubMenu from 'antd/es/menu/SubMenu';
import { withRouter } from 'react-router-dom';
import axios from 'axios'
import {connect} from 'react-redux'
const { Sider } = Layout;


const checkpage = (item) => {
  const {role:{rights}}=JSON.parse(localStorage.getItem('token'));
  return item.pagepermisson  && rights.includes(item.key);
}

function SideMenu(props) {

  const [collapsed] = useState(false)
  const [menulist, setmenulist] = useState([])
  useEffect(() => {//请求专用
    //http://localhost:3004/posts?_embed=comments表关联
    axios.get('http://localhost:8000/rights?_embed=children').then(res => {
      setmenulist(res.data);
    })
  }, [])//传空数组
  const renderMenu = (menulist) => {
    return menulist.map(item => {
      if (item.children?.length > 0 && checkpage(item)) {
        return <SubMenu key={item.key} title={item.title} >
          {renderMenu(item.children)}
        </SubMenu>
      }
      return checkpage(item) && <Menu.Item key={item.key} onClick={() => {
        props.history.push(item.key)
      }}>
        <Icon type={item.icon} />
        <span>{item.title}</span>
      </Menu.Item>
    })
  }

  const openkey = () => {
   return ['/'+props.history.location.pathname.split('/')[1]] 
  }

  return (
    <Sider
      trigger={null}
      collapsible
      collapsed={props.isCollapsed}
    >
      <div className="logo">新闻发布管理系统</div>
      <Menu theme="dark" mode="inline"  selectedKeys={[props.history.location.pathname]} defaultOpenKeys={openkey()}>
        {
          renderMenu(menulist)
        }
      </Menu>
    </Sider>
  )
}
const mapStateToProps=({CollApsedReducer:{isCollapsed}})=>{//props里面就会有属性
  return {
    isCollapsed
  }
}

export default connect(mapStateToProps)(withRouter(SideMenu));