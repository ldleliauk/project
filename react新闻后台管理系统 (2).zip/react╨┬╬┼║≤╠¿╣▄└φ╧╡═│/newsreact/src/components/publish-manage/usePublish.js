import { useEffect, useState } from 'react'
import axios from 'axios'
import { message } from 'antd';
function usePublish(type) {
    const { username } = JSON.parse(localStorage.getItem('token'));
    const [dataSource, setdataSource] = useState([])

    async function handelPublish(id) {
       await axios.patch(`http://localhost:8000/news/${id}`,{
            "publishState": 2,
            "publishTime": Date.now()
        }).then(res=>{
            message.success(`你可以在【发布管理/已经发布】中查看您的新闻`)
            })

        await  axios.get(`http://localhost:8000/news?author=${username}&publishState=${type}&_expand=category`).then(res => {
            setdataSource(res.data)
        })
    }
    async function handelSunset(id){
        await axios.patch(`http://localhost:8000/news/${id}`,{
            "publishState": 3,
        }).then(res=>{
            message.success(`你可以在【发布管理/已经下线】中查看您的新闻`)
            })
        await  axios.get(`http://localhost:8000/news?author=${username}&publishState=${type}&_expand=category`).then(res => {
            setdataSource(res.data)
        })
    }
    async function handelDelete(id){
        await axios.delete(`http://localhost:8000/news/${id}`).then(res=>{
            message.success('您已经成功删除了此新闻')
        })
        await  axios.get(`http://localhost:8000/news?author=${username}&publishState=${type}&_expand=category`).then(res => {
            setdataSource(res.data)
        })
    }
    useEffect(() => {
        axios.get(`http://localhost:8000/news?author=${username}&publishState=${type}&_expand=category`).then(res => {
            setdataSource(res.data)
        })
    }, [username])
    return {
        dataSource,
        handelDelete,
        handelPublish,
        handelSunset
    }
}
export default usePublish
