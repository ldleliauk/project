import React from 'react'
import { BrowserRouter, Route } from 'react-router-dom'
import Login from '../views/login/Login'
import NewsSandBox from '../views/newssandbox/NewsSandBox'
import { Redirect, Switch } from 'react-router-dom/cjs/react-router-dom.min'
import News from '../views/news/News'
import Detail from '../views/news/Detail'
export default function indexrouter() {
    return (
            <BrowserRouter>
                <Switch>
                    <Route path='/login' component={Login}></Route>
                    <Route path='/news' component={News}></Route>
                    <Route path='/detail/:id' component={Detail}></Route>
                    <Route path='/' render={()=>
                       localStorage.getItem('token')?<NewsSandBox></NewsSandBox>:<Redirect to="/login"/>
                    }></Route>
                </Switch>
            </BrowserRouter>
    )
}
