//跨域反向代理
// npm install http-proxy-middleware   下载代理核心
const {createProxyMiddleware} =require('http-proxy-middleware');
module.exports = function(app){
    app.use(
        '/horn',
        createProxyMiddleware(
            {
                target:'https://portal-portm.meituan.com',
                changeOrigin:true
            }
        )
    )
}