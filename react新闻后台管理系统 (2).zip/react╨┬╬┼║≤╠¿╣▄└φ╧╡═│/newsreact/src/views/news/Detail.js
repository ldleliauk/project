import React, { useEffect, useState } from 'react'
import { Descriptions } from 'antd';
import moment from 'moment'
import axios from 'axios'
import { HeartOutlined } from '@ant-design/icons'
export default function Detail(props) {
    const [newsInfo, setnewsInfo] = useState(null);
    useEffect(() => {
        axios.get(`http://localhost:8000/news/${props.match.params.id}?_expand=category&_expand=role`).then(res => {
            setnewsInfo({
                ...res.data,
                view: res.data.view + 1
            })
            return res.data
        }).then(res => {
            axios.patch(`http://localhost:8000/news/${props.match.params.id}`, {
                view: res.view + 1
            })
        })
    }, []);


    const heartstar=()=>{
        setnewsInfo({
            ...newsInfo,
           star: newsInfo.star + 1
        })
        axios.patch(`http://localhost:8000/news/${props.match.params.id}`, {
            star: newsInfo.star + 1
            })
    }
    let publishTime = newsInfo ? newsInfo.publishTime : '';

    const items = [
        {
            key: '1',
            label: '创建者',
            children: newsInfo ? newsInfo.author : '',
        },
        {
            key: '3',
            label: '发布时间',
            children: publishTime ? moment(publishTime).format('YYYY/MM/DD HH:mm:ss') : '-',
        },
        {
            key: '4',
            label: '区域',
            children: newsInfo ? newsInfo.region : '',
        },
        {
            key: '7',
            label: '访问数量',
            children: <span style={{ color: 'green' }}> {newsInfo ? newsInfo.view : ''}</span>,
        },
        {
            key: '8',
            label: '点赞数量',
            children: <span style={{ color: 'green' }}> {newsInfo ? newsInfo.star : ''}</span>,
        },
        {
            key: '9',
            label: '评论数量',
            children: <span style={{ color: 'green' }}>0</span>,
        },
    ];
    return (
        <div>

            <Descriptions title={<div>新闻预览{<span style={{ marginLeft: '15px' }} onClick={()=>{
                heartstar()
            }}><HeartOutlined /></span>}</div>} items={items} />
            <div dangerouslySetInnerHTML={{
                __html: newsInfo ? newsInfo.content : ''
            }} style={{
                border: '1px solid gray',
                paddingLeft: '5px',
                borderRadius: '15px'
            }}>
            </div>
        </div>
    )
}
