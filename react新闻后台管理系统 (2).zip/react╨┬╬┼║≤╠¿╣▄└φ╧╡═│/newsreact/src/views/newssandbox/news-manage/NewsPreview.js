import React, { useEffect, useState } from 'react'
import { Descriptions } from 'antd';
import moment from 'moment'
import axios from 'axios'
export default function NewsPreview(props) {
  const [newsInfo,setnewsInfo]=useState(null);
useEffect(()=>{
  axios.get(`http://localhost:8000/news/${props.match.params.id}?_expand=category&_expand=role`).then(res=>{
    setnewsInfo(res.data)
})
},[]);
let nowdate= newsInfo ? newsInfo.createTime:'';
let publishTime=newsInfo ? newsInfo.publishTime : '';
const auditList=['未审核','审核中','已通过','未通过'];
const publishList=['未发布','待发布','已上线','已下线'];
const colorlist=['black','orange','green','red']
  const items = [
    {
      key: '1',
      label: '创建者',
      children:  newsInfo ? newsInfo.author : '',
    },
    {
      key: '2',
      label: '创建时间',
      children:   moment(nowdate).format('YYYY/MM/DD HH:mm:ss'),
    },
    {
      key: '3',
      label: '发布时间',
      children: publishTime?moment(publishTime).format('YYYY/MM/DD HH:mm:ss'):'-',
    },
    {
      key: '4',
      label: '区域',
      children: newsInfo ? newsInfo.region : '',
    },
    {
      key: '5',
      label: '审核状态',
      children: <span style={{color:colorlist[newsInfo ? newsInfo.auditState:'']}}>{auditList[newsInfo ? newsInfo.auditState:'']}</span>,
    },
    {
      key: '6',
      label: '发布状态',
      children: <span style={{color:colorlist[newsInfo ? newsInfo.publishState:'']}}>{publishList[newsInfo ? newsInfo.publishState:'']}</span>,
    },
    {
      key: '7',
      label: '访问数量',
      children: <span style={{color:'green'}}> {newsInfo ? newsInfo.view:''}</span>,
    },
    {
      key: '8',
      label: '点赞数量',
      children: <span style={{color:'green'}}> {newsInfo ? newsInfo.star:''}</span>,
    },
    {
      key: '9',
      label: '评论数量',
      children: <span style={{color:'green'}}>0</span>,
    },
  ];
  return (
    <div>
      <Descriptions title="新闻预览" items={items} />
      <div dangerouslySetInnerHTML={{
        __html:newsInfo ?newsInfo.content:''
      }} style={{
        border:'1px solid gray',
        paddingLeft:'5px',
       borderRadius:'15px'
      }}>
      </div>
    </div>
  )
}
