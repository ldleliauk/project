import React, { useEffect, useState } from 'react'
import { Table, Button, Modal, message } from 'antd'
import axios from 'axios'
import { DeleteOutlined, EditOutlined, ExclamationCircleOutlined, CloudUploadOutlined } from '@ant-design/icons'
const { confirm } = Modal

export default function NewsDraft(props) {
  const [dataSource, setdataSoure] = useState([]);
  const { username } = JSON.parse(localStorage.getItem('token'));
  const catetitle = ['时事新闻', '环球经济', '科学技术', '军事世界', '世界体育', '生活理财']
  useEffect(() => {
    axios(`http://localhost:8000/news?author=${username}&auditState=0&_expand=category`).then(res => {
      const list = res.data;
      setdataSoure(list)
    })
  }, [username])

  const handelCheck = (id) => {
    axios.patch('http://localhost:8000/news/' + id,{auditState:1}).then(res => {
      props.history.push('/audit-manage/list')
      message.success('您可以在审核列表中查看您的新闻')
      })
  }

  const [columns] = useState([
    {
      title: 'ID',
      dataIndex: 'id',
      render: (id) => {
        return <b>{id}</b>
      }
    },
    {
      title: '新闻标题',
      dataIndex: 'title',
      render: (title, item) => {
        return <a href={`/news-manage/preview/${item.id}`}>{title}</a>
      }
    },
    {
      title: '作者',
      dataIndex: 'author',
    },
    {
      title: '分类',
      dataIndex: 'categoryId',
      render: (categoryId) => {
        return catetitle[categoryId - 1]
      }
    },
    {
      title: '操作',
      dataIndex: 'pagepermisson',
      render: (pagepermisson, all) => {
        return <div>
          <Button danger shape='circle' icon={<DeleteOutlined />} onClick={() => deletebt(all)}></Button>

          <Button type='primary' shape='circle' icon={<EditOutlined />} onClick={() => {
            props.history.push(`/news-manage/update/${all.id}`)
          }}></Button>

          <Button type='primary' shape='circle' icon={<CloudUploadOutlined />} onClick={() => {
            handelCheck(all.id)
          }} ></Button>
        </div>
      }
    },
  ]);

  //删除
  const deletebt = (all) => {
    confirm({
      title: '确定要删除吗？',
      icon: <ExclamationCircleOutlined />,
      content: '',
      async onOk() {
        // 使用 async/await 等待 axios.delete 完成
        await axios.delete(`http://localhost:8000/news/${all.id}`);

        // 删除成功后再更新数据
        setdataSoure(prevDataSource => prevDataSource.filter(item => item.id !== all.id));
      },
      onCancel() {
        return;
      }
    });
  };





  return (
    <div>
      <Table dataSource={dataSource} columns={columns} pagination={{
        pageSize: 5
      }}
        rowKey={item => item.id}
      />
    </div>
  )
}
