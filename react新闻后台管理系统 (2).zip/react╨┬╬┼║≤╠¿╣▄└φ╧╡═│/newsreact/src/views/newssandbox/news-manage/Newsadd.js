import React, { useEffect, useState } from 'react'
import { Button, Steps, Select, Form, Input, message } from 'antd';
import './news.css'
import axios from 'axios'
import NewsEditor from '../../../components/news-manager/NewsEditor';

const { Option } = Select;
export default function Newsadd(props) {
  const [current, setcurrent] = useState(0);
  const [categories, setcategories] = useState([]);
  const [formInfo, setformInfo] = useState({});
  const [InforContent, setInforContent] = useState({});
  const user = JSON.parse(localStorage.getItem('token'));
  const onFinish = (values) => {

    let addcategories = categories.filter(item => {
      return item.value === values.categoryId
    })
    let list={};
    for (var key in addcategories) {
      list[key] = addcategories[key];
    }
    values.categoryId = list[0].id;
    if (current === 1 && Object.keys(InforContent).length === 0 || InforContent === '<p></p>\n') {
      message.error('新闻内容不能为空')
    } else {
      let add = current;
      add++
      setcurrent(add);
      setformInfo(values);
    }
  };
  const onFinishFailed = (errorInfo) => {
    console.log(errorInfo)
  };

  useEffect(() => {
    axios.get('http://localhost:8000/categories').then(res => {
      setcategories(res.data)
    })
  }, [])



  const Savemessage = (auditState) => {
    axios.post('http://localhost:8000/news',{
      ...formInfo,
      "content":InforContent,
      "region": user.region?user.region:"全球",
      "author": user.username,
      "roleId": user.roleId,
      "auditState": auditState,
      "publishState": 0,
      "createTime": Date.now(),
      "star": 0,
      "view": 0,
     // "publishTime": 0
    }).then(res=>{
    props.history.push(auditState===0?'/news-manage/draft':'/audit-manage/list')
    message.success(`你可以在${auditState===0?'草稿箱':'审核列表'}中查看您的新闻`)
    })
  }
  return (
    <div>
      <h2>撰写新闻</h2>
      <div>
        <Steps
          current={current}
          items={[
            {
              title: '基本信息',
              description: '新闻标题,新闻分类',
            },
            {
              title: '新闻内容',
              description: '新闻内容主体'
            },
            {
              title: '新闻提交',
              description: '保存草稿箱或提交审核',
            },
          ]}
        />
      </div>

      <Form
        name="basic"
        labelCol={{
          span: 4,
        }}
        wrapperCol={{
          span: 20,
        }}
        style={{
          maxWidth: 1500,
        }}
        initialValues={{
          remember: true,
        }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <div className={current === 0 ? '' : 'hidden'}>
          <Form.Item
            label="新闻标题"
            name="title"
            rules={[
              {
                required: true,
                message: '请填写标题!',
              },
            ]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="新闻分类"
            name="categoryId"
            rules={[
              {
                required: true,
                message: '请选择分类!',
              },
            ]}
          >
            <Select>
              {
                categories.map((item, index) => <Option key={index} value={item.value} >{item.title}</Option>)
              }
            </Select>
          </Form.Item>
        </div>

        <div className={current === 1 ? '' : 'hidden'}>
          <NewsEditor getContent={(value) => {
            setInforContent(value)

          }}></NewsEditor>
        </div>
        <div className={current === 2 ? '' : 'hidden'}>

        </div>
        <div className='bottomtap'>
          {current > 0 && <Button style={{ marginRight: '10px' }} onClick={() => {
            let code = current;
            code--
            setcurrent(code);
          }}>上一步</Button>}
          {current < 2 && <Button style={{ marginRight: '10px' }} type="primary" htmlType="submit">下一步</Button>}
          {current === 2 && <span><Button style={{ marginRight: '10px' }} type='primary' onClick={() => Savemessage(0)
          }>保存至草稿箱</Button><Button danger onClick={() => Savemessage(1)}>提交审核</Button></span>}
        </div>
      </Form>


    </div >
  )
}

