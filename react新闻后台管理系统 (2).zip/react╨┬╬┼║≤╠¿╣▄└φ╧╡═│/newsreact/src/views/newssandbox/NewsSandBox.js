import React from 'react'
import SideMenu from '../../components/sandbox/SideMenu'
import TopHeader from '../../components/sandbox/TopHeader'
import NewsRouter from '../../components/sandbox/NewsRouter'
import './NewsSandBox.css'
import { Layout } from 'antd';
// import NProgress from 'nprogress'
// import 'nprogress/nprogress.css'
var { Content } = Layout

export default function NewsSandBox() {
  // NProgress.start();
  // useEffect(()=>{
  //   NProgress.done();
  // },[])
  return (
    <Layout>
      <SideMenu></SideMenu>
      <Layout className='site-layout'>
        <TopHeader></TopHeader>
        <Content style={{ margin: '24px 16px', padding: 24, background: '#fff', minHeight: 280 }}>
          <NewsRouter></NewsRouter>
        </Content>
      </Layout>
    </Layout>
  )
}
