import React, { useEffect, useState, useRef } from 'react'
import { Table, Button, Switch, Modal } from 'antd'
import { DeleteOutlined, UnorderedListOutlined, ExclamationCircleOutlined } from '@ant-design/icons'
import axios from 'axios'
import UseForm from '../../../components/user-manage/UseForm'
const { confirm } = Modal;

export default function Userlist() {
  const [dataSource, setdataSource] = useState([]);
  const [Updatmodal, setUpdatmodal] = useState(false);
  const [open, setOpen] = useState(false);
  const [roleList, setroleList] = useState([]);
  const [regionList, setregionList] = useState([]);
  const updateForm = useRef(null);
  const addForm = useRef(null);
  const [selectedItem, setSelectedItem] = useState(null);
  const [isjyable, setisjyable] = useState(false)

  const creatForm = (value) => {
    setOpen(false);
    addForm.current.resetFields();
    axios.post('http://localhost:8000/users', {
      ...value,
      "roleState": true,
      "default": false
    }).then(res => {
      getdata();
    })
  }
  const onCancel = () => {
    setOpen(false);
  }



  const columns = [{
    title: '区域',
    dataIndex: 'region',
    filters: [
      ...regionList.map(item => ({
        text: item.title,
        value:item.value
      })),
      {
        text:'全球',
        value:''
      }
    ],
    onFilter:(value,item)=>item.region===value,
    render: (region) => {
      return <b>{region === '' ? '全球' : region}</b>
    }
  },
  {
    title: '角色名称',
    dataIndex: 'role',
    render: (role) => {
      return role.roleName
    }
  },
  {
    title: '用户名',
    dataIndex: 'username',
  },
  {
    title: '用户状态',
    dataIndex: 'roleState',
    render: (roleState, item) => {
      return <div>
        <Switch checked={roleState} disabled={item.default} onChange={() => Changstate(item)}></Switch>
      </div>
    }
  },
  {
    title: '操作',
    dataIndex: 'pagepermisson',
    render: (pagepermisson, item) => {
      return <div>
        <Button danger shape='circle' icon={<DeleteOutlined />} disabled={item.default} onClick={() =>
          deletebt(item)}></Button>
        <Button type='primary' shape='circle' icon={<UnorderedListOutlined />} disabled={item.default} onClick={() => {
          handleupdate(item)
        }}></Button>
      </div>
    }
  }]
  const {roleId,region,username}=JSON.parse(localStorage.getItem('token'));
  const roleObj={
    "1":"superadmin",
    "2":"admin",
    "3":"editor"
  }
  //数据
  const getdata = () => {
    axios.get('http://localhost:8000/users?_expand=role').then(res => {
      const list=res.data
      setdataSource(roleObj[roleId]==="superadmin"?list:[...list.filter(item=>item.username===username),...list.filter(item=>item.region===region&&roleObj[item.roleId]==='editor')])
    })
  }
  const getroles = () => {
    axios.get('http://localhost:8000/roles').then(res => {
      setroleList(res.data)
    })
  }
  const getregions = () => {
    axios.get('http://localhost:8000/regions').then(res => {
      setregionList(res.data)
    })
  }
  useEffect(() => {
    getdata();
    getroles();
    getregions();
  }, [])

  const deletebt = (all) => {
    confirm({
      title: '确定要删除吗？',
      icon: <ExclamationCircleOutlined />,
      content: '',
      async onOk() {
        // 等待异步操作完成
        await axios.delete(`http://localhost:8000/users/${all.id}`);
        getdata()
      },
      onCancel() {
        return
      }
    })
  }


  const Changstate = (item) => {
    item.roleState = !item.roleState;
    setdataSource([...dataSource]);
    axios.patch(`http://localhost:8000/users/${item.id}`, { roleState: item.roleState })
  }





  const handleupdate = (item) => {
    setSelectedItem(item); // 将选中的项目存储在状态变量中
    setUpdatmodal(true);
  }

  useEffect(() => {
    if (Updatmodal && updateForm.current && selectedItem) {
      // Modal 显示后并且 updateForm 已经初始化时访问 updateForm
      // 同时使用 selectedItem
      if (selectedItem.roleId === 1) {
        setisjyable(true)
      } else {
        setisjyable(false)
      }
      updateForm.current.setFieldsValue(selectedItem);
    }
  }, [Updatmodal, selectedItem]);

  // ... 其他代码 ...  




  async function goupdate(updata) {
    axios.put(`http://localhost:8000/users/${updata.id}`, updata).then(
      await getdata()
    );

  }

  return (
    <div>
      <Button type='primary' onClick={() => {
        setOpen(true);
      }}>添加用户</Button>
      <Table style={{ marginTop: '15px' }} dataSource={dataSource} columns={columns} pagination={{
        pageSize: 5
      }} rowKey={(item) => item.id}></Table>


      <Modal
        open={open}
        title="添加用户"
        okText="确定"
        cancelText="取消"
        onCancel={onCancel}
        onOk={() => {

          addForm.current.validateFields().then(res => {
            creatForm(res);
          }).catch(err => {
            console.log(err)
          })

        }}
      >
        <UseForm ref={addForm} regionList={regionList} roleList={roleList}></UseForm>
      </Modal>




      <Modal
        open={Updatmodal}
        title="更新用户"
        okText="更新"
        cancelText="取消"
        onCancel={() => {
          setUpdatmodal(false)
        }}
        onOk={() => {
          updateForm.current.validateFields().then(res => {
            let id = selectedItem.id;
            let updata = { ...res, id, roleState: selectedItem.roleState };
            goupdate(updata);
            setUpdatmodal(false);
          }).catch(err => {
            console.log(err)
          })

        }}
      >
        <UseForm ref={updateForm} regionList={regionList} roleList={roleList} isjy={isjyable} isupdate={true}></UseForm>
      </Modal>
    </div>
  )
}
