import React, { useEffect, useState } from 'react'
import { Table, Button, Modal, Tree } from 'antd'
import { DeleteOutlined, UnorderedListOutlined, ExclamationCircleOutlined } from '@ant-design/icons'
import axios from 'axios'
const { confirm } = Modal;
export default function Rolelist() {
  const [dataSource, setdataSource] = useState([]);
  const [rights, setrights] = useState([]);
  const [currentRights, setcurrentRights] = useState([]);
  const [currentId, setcurrentId] = useState(0);
  const columns = [{
    title: 'ID',
    dataIndex: 'id',
    render: (id) => {
      return <b>{id}</b>
    }
  },
  {
    title: '角色名称',
    dataIndex: 'roleName',
  },
  {
    title: '操作',
    dataIndex: 'pagepermisson',
    render: (pagepermisson, all) => {
      return <div>
        <Button danger shape='circle' icon={<DeleteOutlined />} onClick={() => deletebt(all)}></Button>
        <Button type='primary' shape='circle' icon={<UnorderedListOutlined />} onClick={() => {
          showModal();
          setcurrentRights(all.rights);
          setcurrentId(all.id);
        }}></Button>
      </div>
    }
  }]



  //弹框
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
    setdataSource(dataSource.map(item => {
      if (item.id === currentId) {
        return {
          ...item,
          rights: currentRights
        }
      }
      return item
    }))
    axios.patch('http://localhost:8000/roles/'+currentId,{
      rights:currentRights
    })
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  //树形
  const onCheck = (checkedKeys) => {
    setcurrentRights(checkedKeys.checked);
  };

  const getdata = () => {
    axios.get('http://localhost:8000/roles').then(res => {
      setdataSource(res.data)
    })
  }

  const getright = () => {
    axios.get('http://localhost:8000/rights?_embed=children').then(res => {
      setrights(res.data);
    })
  }
  useEffect(() => {
    getdata();
    getright();
  }, [])

  const deletebt = (all) => {
    // async function get() {
    //   await axios.delete(`http://localhost:8000/roles/${all.id}`);
    //   getdata()
    // }
    // get()
    confirm({
      title: '确定要删除吗？',
      icon: <ExclamationCircleOutlined />,
      content: '',
      async onOk() {
        // 等待异步操作完成
        await axios.delete(`http://localhost:8000/roles/${all.id}`);
        getdata()
      },
      onCancel() {
        return
      }
    })
  }

  return (
    <div>
      <Table dataSource={dataSource} columns={columns} rowKey={(item) => item.id}></Table>
      <Modal title="权限分配" open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
        <Tree
          checkable
          checkedKeys={currentRights}
          treeData={rights}
          checkStrictly={true}
          onCheck={onCheck}
        />
      </Modal>
    </div>
  )
}
