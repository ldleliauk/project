import React, { useEffect, useState } from 'react'
import { Table, Tag, Button, Modal, Popover, Switch } from 'antd'
import axios from 'axios'
import { DeleteOutlined, EditOutlined, ExclamationCircleOutlined } from '@ant-design/icons'
const { confirm } = Modal

export default function Rightlist() {
  const [dataSource, setdataSoure] = useState([]);

  useEffect(() => {
    axios('http://localhost:8000/rights?_embed=children').then(res => {
      const list = res.data;
      list.forEach(item => {
        if (item.children.length === 0) {
          item.children = ''
        }
      })
      setdataSoure(list)
    })
  }, [])

  const [columns] = useState([
    {
      title: 'ID',
      dataIndex: 'id',
      render: (id) => {
        return <b>{id}</b>
      }
    },
    {
      title: '权限名称',
      dataIndex: 'title',
    },
    {
      title: '权限路径',
      dataIndex: 'key',
      render: (key) => {
        return <Tag color="blue">{key}</Tag>
      }
    },
    {
      title: '操作',
      dataIndex: 'pagepermisson',
      render: (pagepermisson, all) => {
        return <div>
          <Button danger shape='circle' icon={<DeleteOutlined />} onClick={() => deletebt(all)}></Button>
          <Popover content={<div style={{ textAlign: 'center' }}><Switch checked={all.pagepermisson} onChange={() => switchMethod(all)}></Switch></div>} title="配置选项" trigger={all.pagepermisson === undefined ? '' : 'click'}>
            <Button type='primary' shape='circle' icon={<EditOutlined />} disabled={all.pagepermisson === undefined}></Button>
          </Popover>
        </div>
      }
    },
  ]);

  //删除
  const deletebt = (all) => {
    confirm({
      title: '确定要删除吗？',
      icon: <ExclamationCircleOutlined />,
      content: '',
      async onOk() {
        // 等待异步操作完成

        if (all.grade === 1) {
          await axios.delete(`http://localhost:8000/rights/${all.id}`);
          // 更新 dataSource
          setdataSoure(prevDataSource => prevDataSource.filter(item => item.id !== all.id));
        } else {

          await axios.delete(`http://localhost:8000/children/${all.id}`);
          // 更新 dataSource
          axios('http://localhost:8000/rights?_embed=children').then(res => {
            setdataSoure(res.data);
          })
        }
      },
      onCancel() {
        return
      }
    })
  }

  const switchMethod = (all) => {
    let newpagepermisson=all.pagepermisson===1?0:1
    if (all.grade === 1) {
       axios.patch(`http://localhost:8000/rights/${all.id}`,{pagepermisson:newpagepermisson});
     
    } else {

       axios.patch(`http://localhost:8000/children/${all.id}`,{pagepermisson:newpagepermisson});
     
    }
    axios('http://localhost:8000/rights?_embed=children').then(res => {
      setdataSoure(res.data);
    })
  }


  return (
    <div>
      <Table dataSource={dataSource} columns={columns} pagination={{
        pageSize: 5
      }} rowKey={item=>item.id}/>
    </div>
  )
}
