import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Table, Tag,Button, message} from 'antd'
export default function AuditList(props) {
  const { username } = JSON.parse(localStorage.getItem('token'));
  const [dataSource, setdataSoure] = useState([]);
  useEffect(() => {
    axios.get(`http://localhost:8000/news?author=${username}&auditState_ne=0&publishState_lte=1&_expand=category`).then(res => {
      setdataSoure(res.data)
    })
  }, []);
async function handleRervert(item){

await axios.patch(`http://localhost:8000/news/${item.id}`,{
  auditState:0
}).then(res=>{
  message.success('您可以在草稿箱中查看您的新闻')
})

await axios.get(`http://localhost:8000/news?author=${username}&auditState_ne=0&publishState_lte=1&_expand=category`).then(res => {
      setdataSoure(res.data)
    })
}

const handelpublish=(item)=>{
  axios.patch(`http://localhost:8000/news/${item.id}`,{
    "publishState": 2,
    "publishTime": Date.now()
}).then(res=>{
    props.history.push('/publish-manage/published')
    message.success(`你可以在【发布管理/已经发布】中查看您的新闻`)
    })
}

const  handelupdate=(item)=>{
props.history.push(`/news-manage/update/${item.id}`)
}

  const [columns] = useState([
    {
      title: '新闻标题',
      dataIndex: 'title',
      render: (title,item) => {
        return <a href={'/news-manage/preview/'+item.id}>{title}</a>
      }
    },
    {
      title: '作者',
      dataIndex: 'author',
    },
    {
      title: '新闻分类',
      dataIndex: 'category',
      render: (category) => {
        return <div>{category.title}</div>
      }
    },
    {
      title: '审核状态',
      dataIndex: 'auditState',
      render: (auditState) => {
        const colorlist=['','orange','green','red'];
        const auditlist=['','审核中','已通过','未通过']
        return <Tag color={colorlist[auditState]}>{auditlist[auditState]}</Tag>
      }
    },
    {
      title: '操作',
      render: (item) => {
        return <div>
          {
            item.auditState===1 &&<Button danger onClick={()=>
              handleRervert(item)
            }>撤销</Button>
          }
          {
            item.auditState===2 &&<Button type='primary' onClick={()=>handelpublish(item)}>发布</Button>
          }
          {
            item.auditState===3 &&<Button  onClick={()=>
            handelupdate(item)}>更新</Button>
          }
        </div>
      }
    }
  ]);
  return (
    <div>
      <Table dataSource={dataSource} columns={columns} pagination={{
        pageSize: 5
      }}

        rowKey={item => item.id}/>
    </div>
  )
}

