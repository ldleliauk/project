import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Button, Table, Tag, message } from 'antd'
const { roleId, region, username } = JSON.parse(localStorage.getItem('token'));
export default function Audit() {
  const [dataSource, setdataSoure] = useState([])
  const roleObj = {
    "1": "superadmin",
    "2": "admin",
    "3": "editor"
  }
  useEffect(() => {
    
    axios.get('http://localhost:8000/news?auditState=1&_expand=category').then(res => {
      const list = res.data
      setdataSoure(roleObj[roleId] === "superadmin" ? list : [...list.filter(item => item.author === username), ...list.filter(item => item.region === region && roleObj[item.roleId] === 'editor')])
    }
    )
  }, [roleId, region, username])

  async function handelAudit(item, auditState, publishState) {
   await axios.patch('http://localhost:8000/news/' + item.id, {
      auditState,
      publishState
    }).then(res => {
      message.success('您可以在【审核管理/审核列表】中查看您的新闻的审核状态')
    })
   await axios.get('http://localhost:8000/news?auditState=1&_expand=category').then(res => {
      const list = res.data
      setdataSoure(roleObj[roleId] === "superadmin" ? list : [...list.filter(item => item.author === username), ...list.filter(item => item.region === region && roleObj[item.roleId] === 'editor')])
    }
    )

  }
  const [columns] = useState([
    {
      title: '新闻标题',
      dataIndex: 'title',
      render: (title, item) => {
        return <a href={'/news-manage/preview/' + item.id}>{title}</a>
      }
    },
    {
      title: '作者',
      dataIndex: 'author',
    },
    {
      title: '新闻分类',
      dataIndex: 'category',
      render: (category) => {
        return <div>{category.title}</div>
      }
    },
    {
      title: '审核状态',
      dataIndex: 'auditState',
      render: (auditState) => {
        const colorlist = ['', 'orange', 'green', 'red'];
        const auditlist = ['', '审核中', '已通过', '未通过']
        return <Tag color={colorlist[auditState]}>{auditlist[auditState]}</Tag>
      }
    },
    {
      title: '操作',

      render: (item) => {
        return <div>
          <Button type='primary' onClick={() => handelAudit(item, 2, 1)}>通过</Button>
          <Button danger onClick={() => handelAudit(item, 3, 0)}>驳回</Button>
        </div>
      }
    },
  ]);
  return (
    <div><Table dataSource={dataSource} columns={columns} pagination={{
      pageSize: 5
    }}

      rowKey={item => item.id} /></div>
  )
}
